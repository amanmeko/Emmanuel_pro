<?php return array (
  'post' => 'App\\Http\\Livewire\\Post',
  'post-create' => 'App\\Http\\Livewire\\PostCreate',
);