
<div>
    <div class="max-w-4xl mx-auto py-20">
        <h1>{{ $post->title }}</h1>
        <p>{!! $post->body !!}</p>
    </div>
</div>

